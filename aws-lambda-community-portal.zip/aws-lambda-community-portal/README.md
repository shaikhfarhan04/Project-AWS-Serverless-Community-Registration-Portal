# AWS Lambda Community Portal

Beginner-friendly serverless community portal using Python 3.12, API Gateway HTTP API,
Cognito JWT authentication, DynamoDB, private S3 uploads, Terraform and GitHub Actions.

## Architecture
Browser/client -> API Gateway HTTP API -> Python Lambda -> DynamoDB and private S3.
Cognito issues JWTs; API Gateway validates them before protected routes reach Lambda.
CloudWatch receives Lambda logs. GitHub Actions can deploy through AWS OIDC.

## Prerequisites
- AWS account with permissions to create IAM, Lambda, API Gateway, Cognito, DynamoDB and S3 resources.
- AWS CLI v2, Terraform >= 1.10, Python 3.12, Git.
- A configured AWS CLI profile (`aws configure`) for local deployment.
- An AWS region, e.g. `ap-south-1`.

## 1. Local setup
```bash
aws --version
aws sts get-caller-identity
terraform version
python3 --version
cd aws-lambda-community-portal
python3 -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements-dev.txt
pytest -q
```

## 2. Configure Terraform
```bash
cd infra
cp terraform.tfvars.example terraform.tfvars
```
Edit `terraform.tfvars` and set a globally unique `project_name` (lowercase letters,
numbers and hyphens; 3-20 chars), AWS region and allowed frontend origin.
Do not commit `terraform.tfvars`.

### Create the Terraform state bucket (one-time bootstrap)
Terraform needs a persistent state file before CI/CD can safely deploy. Create a separate,
globally unique bucket (do not use the application's uploads bucket):
```bash
aws s3api create-bucket --bucket YOUR-UNIQUE-TF-STATE-BUCKET --region ap-south-1 \
  --create-bucket-configuration LocationConstraint=ap-south-1
aws s3api put-public-access-block --bucket YOUR-UNIQUE-TF-STATE-BUCKET \
  --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true
aws s3api put-bucket-versioning --bucket YOUR-UNIQUE-TF-STATE-BUCKET \
  --versioning-configuration Status=Enabled
aws s3api put-bucket-encryption --bucket YOUR-UNIQUE-TF-STATE-BUCKET \
  --server-side-encryption-configuration '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'
```
Create `infra/backend.hcl` (do not commit it):
```hcl
bucket       = "YOUR-UNIQUE-TF-STATE-BUCKET"
key          = "community-portal/dev/terraform.tfstate"
region       = "ap-south-1"
encrypt      = true
use_lockfile = true
```
The backend bucket is intentionally created outside this stack so Terraform does not need
to manage the bucket that stores its own state. Protect and back up this bucket.

## 3. Deploy
```bash
terraform init -backend-config=backend.hcl
terraform fmt -recursive
terraform validate
terraform plan
terraform apply
```
Type `yes` when Terraform asks. Save the outputs:
```bash
terraform output -raw api_endpoint
terraform output -raw cognito_user_pool_id
terraform output -raw cognito_app_client_id
terraform output -raw cognito_issuer
terraform output -raw uploads_bucket
```

## 4. Create a test Cognito user
This starter uses Cognito's email/password sign-in. Create a user with the AWS CLI:
```bash
aws cognito-idp sign-up \
  --client-id "$(terraform output -raw cognito_app_client_id)" \
  --username "your-email@example.com" \
  --password 'ChangeThis-Password-123!' \
  --user-attributes Name=email,Value=your-email@example.com \
  --region ap-south-1
```
Confirm the user. For a learning account, an administrator can confirm it:
```bash
aws cognito-idp admin-confirm-sign-up \
  --user-pool-id "$(terraform output -raw cognito_user_pool_id)" \
  --username "your-email@example.com" \
  --region ap-south-1
```
Get an access token:
```bash
aws cognito-idp initiate-auth \
  --client-id "$(terraform output -raw cognito_app_client_id)" \
  --auth-flow USER_PASSWORD_AUTH \
  --auth-parameters USERNAME="your-email@example.com",PASSWORD='ChangeThis-Password-123!' \
  --region ap-south-1
```
Copy `AuthenticationResult.AccessToken` from the response. Do not paste tokens into source control or chat.

## 5. Call the API
Set the endpoint and token in your terminal (replace values):
```bash
API="$(cd infra && terraform output -raw api_endpoint)"
TOKEN='PASTE_ACCESS_TOKEN_HERE'
```
Health check (public):
```bash
curl "$API/health"
```
Create/update your own member profile:
```bash
curl -X POST "$API/members" \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"full_name":"Test Member","city":"Pune","skills":["Python","AWS"]}'
```
Read your profile:
```bash
curl "$API/members/me" -H "Authorization: Bearer $TOKEN"
```
Create a pre-signed upload URL:
```bash
curl -X POST "$API/documents/presign" \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"filename":"resume.pdf","content_type":"application/pdf"}'
```
Copy `upload_url` and `document_id` from response. Upload directly to S3:
```bash
curl -X PUT 'PASTE_UPLOAD_URL_HERE' \
  -H 'Content-Type: application/pdf' --data-binary @resume.pdf
```
List your documents:
```bash
curl "$API/documents" -H "Authorization: Bearer $TOKEN"
```
Generate a short-lived download URL:
```bash
curl "$API/documents/DOCUMENT_ID/download" -H "Authorization: Bearer $TOKEN"
```

## 6. Tests
```bash
cd ..
pytest -q
```
For an AWS integration test, deploy first and use the curl commands above. Never use real
personal documents in a learning environment.

## 7. GitHub
Create an empty GitHub repository, then:
```bash
git init
git add .
git commit -m "Initial serverless community portal"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USER/YOUR_REPOSITORY.git
git push -u origin main
```
The included workflow runs tests and Terraform validation on pull requests. Deployment on
push to `main` requires the remote state bucket above, GitHub OIDC configured in AWS, and
repository variables: `AWS_ROLE_ARN`, `AWS_REGION`, `AWS_STATE_BUCKET`. The IAM role must trust only your repository and main branch,
and have narrowly scoped deployment permissions. See `docs/CI_CD.md`.

## 8. Cleanup (avoid ongoing charges)
From `infra/`:
```bash
terraform destroy
```
Type `yes`. This removes the portal resources, including uploaded objects. Back up anything
you need first. The Terraform state file contains infrastructure metadata; protect it.
