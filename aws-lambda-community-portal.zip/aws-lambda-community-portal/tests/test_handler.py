import json
import os
import sys
from pathlib import Path

os.environ.setdefault("TABLE_NAME", "unit-test-table")
os.environ.setdefault("BUCKET_NAME", "unit-test-bucket")
os.environ.setdefault("AWS_DEFAULT_REGION", "us-east-1")
os.environ.setdefault("AWS_ACCESS_KEY_ID", "testing")
os.environ.setdefault("AWS_SECRET_ACCESS_KEY", "testing")
sys.path.insert(0, str(Path(__file__).parents[1] / "app"))

from handler import lambda_handler


def test_health_is_public():
    event = {
        "requestContext": {"http": {"method": "GET"}},
        "rawPath": "/health",
    }
    result = lambda_handler(event, None)
    assert result["statusCode"] == 200
    assert json.loads(result["body"])["status"] == "ok"


def test_unknown_route_requires_authentication():
    event = {
        "requestContext": {"http": {"method": "GET"}},
        "rawPath": "/not-a-route",
    }
    result = lambda_handler(event, None)
    assert result["statusCode"] == 401


def test_invalid_json_returns_400(monkeypatch):
    # Simulate an authenticated API Gateway event; parsing fails before AWS access.
    event = {
        "requestContext": {
            "http": {"method": "POST"},
            "authorizer": {"jwt": {"claims": {"sub": "test-sub"}}},
        },
        "rawPath": "/members",
        "body": "{invalid-json",
    }
    result = lambda_handler(event, None)
    assert result["statusCode"] == 400
