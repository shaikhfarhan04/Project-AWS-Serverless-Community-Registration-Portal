# GitHub Actions CI/CD using AWS OIDC

The workflow in `.github/workflows/ci-cd.yml` runs tests and Terraform checks on pull
requests. A push to `main` runs deployment after tests pass. It uses an S3 remote backend
with state locking; bootstrap the state bucket as described in the root README first.

## Configure OIDC
1. Create an AWS IAM OIDC identity provider for
   `https://token.actions.githubusercontent.com`, audience `sts.amazonaws.com`.
   Create it only if your account does not already have it.
2. Create a deployment role whose trust policy restricts `sub` to
   `repo:YOUR_GITHUB_USER/YOUR_REPOSITORY:ref:refs/heads/main` and `aud` to
   `sts.amazonaws.com`.
3. Attach a deployment policy appropriate for the resources in this project. Terraform
   deployment requires permissions to manage the specific Lambda, API Gateway, Cognito,
   DynamoDB, S3, IAM role/policy, CloudWatch log group and random-id resources, plus
   read-only access to account/partition identity. Scope resource ARNs wherever AWS supports
   it. IAM role creation and `iam:PassRole` need especially careful scoping to the Lambda
   execution role created by this stack. Do not attach AdministratorAccess in production.
4. In GitHub repository Settings -> Secrets and variables -> Actions -> Variables, add:
   - `AWS_ROLE_ARN`: deployment role ARN
   - `AWS_REGION`: e.g. `ap-south-1`
   - `AWS_STATE_BUCKET`: the pre-created, versioned Terraform state bucket
5. Push to `main` and inspect the Actions run.

OIDC provides short-lived credentials. Do not store AWS access keys in GitHub secrets.
Protect `main` with required pull-request reviews and restrict who can change workflow files.

For a beginner lab, first deploy manually from your own workstation. Add CI deployment only
after you understand and have reviewed the IAM deployment policy. Use a separate AWS account
or sandbox for experiments.
