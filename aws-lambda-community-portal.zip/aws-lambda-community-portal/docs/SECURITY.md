# Security notes and limitations

- Cognito authenticates users. API Gateway validates JWTs on every protected route.
- Lambda reads the verified Cognito `sub` claim, not a user ID supplied by the caller.
  Each DynamoDB partition is scoped to that `sub`, preventing cross-member reads.
- S3 blocks public access, enables server-side encryption and versioning. Objects are
  stored under `members/<cognito-sub>/...`.
- Upload URLs expire after five minutes and are signed for a specific object key and
  Content-Type. The browser uploads directly to S3.
- Lambda's role has only DynamoDB GetItem/PutItem/Query and S3 PutObject/GetObject on
  the app's bucket prefix, plus CloudWatch logging.
- Never commit credentials, access tokens, real user data, `.tfvars`, or Terraform state.
- The starter validates filename and MIME type, but MIME type is not proof of file content.
  Production systems should inspect file signatures, enforce upload size using a controlled
  upload service or presigned POST policy, scan files for malware, and consider quarantine.
- `MAX_UPLOAD_BYTES` is returned to the client but a presigned PUT URL does not enforce
  that byte limit. Do not treat this as a hard upload-size control.
- The sample does not implement account deletion, email delivery, rate limiting, CAPTCHA,
  audit trails for business events, or a frontend. Add these before public production use.
- Do not log access tokens, passwords, presigned URLs or uploaded file contents.
- Enable AWS Budgets and billing alerts before experimenting.
