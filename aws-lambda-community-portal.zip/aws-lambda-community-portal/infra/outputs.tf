output "api_endpoint" { value = aws_apigatewayv2_api.http.api_endpoint }
output "uploads_bucket" { value = aws_s3_bucket.uploads.bucket }
output "dynamodb_table" { value = aws_dynamodb_table.members.name }
output "lambda_function_name" { value = aws_lambda_function.api.function_name }
output "cognito_user_pool_id" { value = aws_cognito_user_pool.users.id }
output "cognito_app_client_id" { value = aws_cognito_user_pool_client.web.id }
output "cognito_issuer" {
  value = "https://cognito-idp.${var.aws_region}.amazonaws.com/${aws_cognito_user_pool.users.id}"
}
