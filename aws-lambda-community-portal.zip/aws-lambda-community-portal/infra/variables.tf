variable "aws_region" {
  description = "AWS region for all resources"
  type        = string
  default     = "ap-south-1"
}
variable "project_name" {
  description = "Globally unique short project prefix"
  type        = string
  default     = "community-portal-demo"
  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,19}$", var.project_name))
    error_message = "Use 3-20 lowercase letters, numbers or hyphens; start with a letter."
  }
}
variable "environment" {
  type    = string
  default = "dev"
}
variable "allowed_origin" {
  description = "Frontend origin for API CORS; use your real HTTPS domain in production"
  type        = string
  default     = "http://localhost:3000"
}
variable "lambda_timeout" {
  type    = number
  default = 15
}
variable "lambda_memory" {
  type    = number
  default = 256
}
