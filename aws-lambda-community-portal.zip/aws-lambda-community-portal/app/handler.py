import json
import os
import re
import uuid
from datetime import datetime, timezone
from urllib.parse import unquote

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

TABLE_NAME = os.environ["TABLE_NAME"]
BUCKET_NAME = os.environ["BUCKET_NAME"]
MAX_UPLOAD_BYTES = int(os.environ.get("MAX_UPLOAD_BYTES", "10485760"))
ALLOWED_TYPES = {"application/pdf", "image/png", "image/jpeg",
                 "application/vnd.openxmlformats-officedocument.wordprocessingml.document"}

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)
s3 = boto3.client("s3")


def response(status, body):
    return {
        "statusCode": status,
        "headers": {
            "content-type": "application/json",
            "cache-control": "no-store",
            "x-content-type-options": "nosniff",
        },
        "body": json.dumps(body, default=str),
    }


def parse_body(event):
    raw = event.get("body") or "{}"
    if event.get("isBase64Encoded"):
        raise ValueError("Base64 request bodies are not supported on this endpoint")
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("JSON body must be an object")
    return value


def user_sub(event):
    # API Gateway HTTP API JWT authorizer injects verified claims here.
    claims = event.get("requestContext", {}).get("authorizer", {}).get("jwt", {}).get("claims", {})
    sub = claims.get("sub")
    if not sub:
        raise PermissionError("A valid Cognito access token is required")
    return str(sub)


def lambda_handler(event, context):
    method = event.get("requestContext", {}).get("http", {}).get("method", "")
    path = event.get("rawPath", "/")
    try:
        if method == "GET" and path == "/health":
            return response(200, {"status": "ok", "service": "community-portal"})

        member_id = user_sub(event)

        if method == "POST" and path == "/members":
            body = parse_body(event)
            name = str(body.get("full_name", "")).strip()
            city = str(body.get("city", "")).strip()
            skills = body.get("skills", [])
            if not name or len(name) > 150:
                return response(400, {"message": "full_name is required (max 150 characters)"})
            if len(city) > 100 or not isinstance(skills, list) or len(skills) > 30:
                return response(400, {"message": "Invalid city or skills"})
            item = {
                "pk": f"MEMBER#{member_id}", "sk": "PROFILE",
                "member_id": member_id, "full_name": name,
                "city": city, "skills": [str(x)[:60] for x in skills],
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            table.put_item(Item=item)
            return response(201, {"message": "Profile saved", "member": item})

        if method == "GET" and path == "/members/me":
            result = table.get_item(Key={"pk": f"MEMBER#{member_id}", "sk": "PROFILE"})
            item = result.get("Item")
            if not item:
                return response(404, {"message": "Profile not found"})
            return response(200, {"member": item})

        if method == "POST" and path == "/documents/presign":
            body = parse_body(event)
            filename = os.path.basename(unquote(str(body.get("filename", "")))).strip()
            content_type = str(body.get("content_type", "")).lower().strip()
            if not filename or len(filename) > 180 or not re.fullmatch(r"[\w .()-]+", filename):
                return response(400, {"message": "Invalid filename"})
            if content_type not in ALLOWED_TYPES:
                return response(415, {"message": "File type is not allowed"})
            document_id = str(uuid.uuid4())
            key = f"members/{member_id}/{document_id}/{filename}"
            upload_url = s3.generate_presigned_url(
                "put_object",
                Params={"Bucket": BUCKET_NAME, "Key": key, "ContentType": content_type},
                ExpiresIn=300,
            )
            item = {
                "pk": f"MEMBER#{member_id}", "sk": f"DOC#{document_id}",
                "document_id": document_id, "filename": filename,
                "content_type": content_type, "s3_key": key,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "max_upload_bytes": MAX_UPLOAD_BYTES,
            }
            table.put_item(Item=item)
            return response(200, {
                "document_id": document_id, "upload_url": upload_url,
                "method": "PUT", "expires_in_seconds": 300,
                "required_headers": {"Content-Type": content_type},
                "max_upload_bytes": MAX_UPLOAD_BYTES,
            })

        if method == "GET" and path == "/documents":
            result = table.query(
                KeyConditionExpression=Key("pk").eq(f"MEMBER#{member_id}") & Key("sk").begins_with("DOC#")
            )
            docs = [{k: v for k, v in item.items() if k != "s3_key"} for item in result.get("Items", [])]
            return response(200, {"documents": docs})

        match = re.fullmatch(r"/documents/([^/]+)/download", path)
        if method == "GET" and match:
            document_id = match.group(1)
            result = table.get_item(Key={"pk": f"MEMBER#{member_id}", "sk": f"DOC#{document_id}"})
            item = result.get("Item")
            if not item:
                return response(404, {"message": "Document not found"})
            url = s3.generate_presigned_url(
                "get_object",
                Params={"Bucket": BUCKET_NAME, "Key": item["s3_key"]},
                ExpiresIn=300,
            )
            return response(200, {"download_url": url, "expires_in_seconds": 300})

        return response(404, {"message": "Route not found"})

    except PermissionError as exc:
        return response(401, {"message": str(exc)})
    except (ValueError, json.JSONDecodeError) as exc:
        return response(400, {"message": str(exc)})
    except ClientError:
        # Detailed AWS errors belong in CloudWatch, not in the public response.
        print("AWS service operation failed")
        return response(500, {"message": "Internal server error"})
    except Exception:
        print("Unhandled application error")
        return response(500, {"message": "Internal server error"})
